//! # Observability — Prometheus metrics + health-check endpoint
//!
//! Exposes a minimal HTTP server that serves:
//! - `GET /metrics` — Prometheus text exposition of live counters/gauges.
//! - `GET /health` — liveness/readiness probe (200 OK when the bot is up).
//!
//! The server is intentionally dependency-light: it uses `tokio::net::TcpListener`
//! and `std::io` to avoid pulling in a full web framework. It is fail-closed:
//! if the metrics registry is unavailable, `/health` still reports the process
//! liveness but `/metrics` returns 503.

use std::collections::HashMap;
use std::sync::Arc;

use prometheus::{
    Encoder, Gauge, Histogram, HistogramOpts, IntCounter, IntCounterVec, Opts, Registry,
    TextEncoder,
};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;

/// Shared metrics registry + counters, cheaply cloneable across tasks.
#[derive(Clone)]
pub struct Metrics {
    registry: Registry,
    pub trades_total: IntCounter,
    pub trades_success: IntCounter,
    pub trades_failed: IntCounter,
    pub hsm_requests: IntCounter,
    pub hsm_errors: IntCounter,
    pub latency_hist: Histogram,
    pub hsm_latency_hist: Histogram,
    pub kill_switch_active: Gauge,
    pub last_trade_ts: Gauge,
    /// Every time the risk gate is evaluated for a candidate trade,
    /// regardless of outcome.
    /// Risk-gate evaluations per operating mode
    /// (`mode`: "paper" | "dry_run" | "live" | "simulation").
    pub trade_attempt_total: IntCounterVec,
    /// Rejections, labeled by operating mode and machine-readable
    /// `RejectReason::code()` (stale_price, slippage_exceeded,
    /// max_spend_exceeded, daily_trade_cap, daily_loss_limit,
    /// circuit_breaker_open, token_authority_risk,
    /// holder_concentration_exceeded, insufficient_liquidity,
    /// hsm_unavailable, ...).
    pub trade_rejected_total: IntCounterVec,
    /// Trades actually executed per mode (live: submitted on-chain; paper:
    /// simulated "would-execute" entries that passed every real gate).
    pub trade_executed_total: IntCounterVec,
    /// Circuit breaker state gauge (1=open/tripped, 0=closed/normal).
    pub circuit_breaker_state: Gauge,
    /// Realized P&L for the current UTC day, in lamports (loss-only today —
    /// see final report for the known gap: no exit-execution path exists to
    /// compute realized wins).
    pub daily_realized_pnl: Gauge,
    /// Number of currently tracked open positions.
    pub open_position_count: Gauge,
    /// Cumulative simulated P&L of closed paper positions, in lamports
    /// (negative = simulated loss). NEVER mixed with `daily_realized_pnl`
    /// which tracks real on-chain P&L only.
    pub paper_simulated_pnl: Gauge,
}

impl Metrics {
    pub fn new() -> Arc<Self> {
        let registry = Registry::new();

        let trades_total = IntCounter::new("hft_trades_total", "Total trade attempts").unwrap();
        let trades_success = IntCounter::new("hft_trades_success", "Successful trades").unwrap();
        let trades_failed = IntCounter::new("hft_trades_failed", "Failed trades").unwrap();
        let hsm_requests = IntCounter::new("hft_hsm_requests", "HSM sign requests").unwrap();
        let hsm_errors = IntCounter::new("hft_hsm_errors", "HSM sign errors").unwrap();
        let latency_hist = Histogram::with_opts(HistogramOpts::new(
            "hft_trade_latency_ms",
            "Trade latency in milliseconds",
        ))
        .unwrap();
        let hsm_latency_hist = Histogram::with_opts(HistogramOpts::new(
            "hft_hsm_latency_ms",
            "HSM sign latency in milliseconds",
        ))
        .unwrap();
        let kill_switch_active =
            Gauge::new("hft_kill_switch_active", "Kill switch state (1=active)").unwrap();
        let last_trade_ts = Gauge::new("hft_last_trade_ts", "Unix ms of last trade").unwrap();

        let trade_attempt_total = IntCounterVec::new(
            Opts::new("trade_attempt_total", "Total risk-gate evaluations"),
            &["mode"],
        )
        .unwrap();
        let trade_rejected_total = IntCounterVec::new(
            Opts::new("trade_rejected_total", "Rejected trades by reason code"),
            &["mode", "reason"],
        )
        .unwrap();
        let trade_executed_total = IntCounterVec::new(
            Opts::new(
                "trade_executed_total",
                "Trades successfully submitted (live) or simulated as executed (paper)",
            ),
            &["mode"],
        )
        .unwrap();
        let circuit_breaker_state = Gauge::new(
            "circuit_breaker_state",
            "Circuit breaker state (1=open/tripped, 0=closed)",
        )
        .unwrap();
        let daily_realized_pnl = Gauge::new(
            "daily_realized_pnl",
            "Realized P&L for the current day, in lamports",
        )
        .unwrap();
        let open_position_count =
            Gauge::new("open_position_count", "Currently tracked open positions").unwrap();
        let paper_simulated_pnl = Gauge::new(
            "paper_simulated_pnl",
            "Cumulative simulated P&L of closed paper positions, in lamports",
        )
        .unwrap();

        registry.register(Box::new(trades_total.clone())).ok();
        registry.register(Box::new(trades_success.clone())).ok();
        registry.register(Box::new(trades_failed.clone())).ok();
        registry.register(Box::new(hsm_requests.clone())).ok();
        registry.register(Box::new(hsm_errors.clone())).ok();
        registry.register(Box::new(latency_hist.clone())).ok();
        registry.register(Box::new(hsm_latency_hist.clone())).ok();
        registry.register(Box::new(kill_switch_active.clone())).ok();
        registry.register(Box::new(last_trade_ts.clone())).ok();
        registry
            .register(Box::new(trade_attempt_total.clone()))
            .ok();
        registry
            .register(Box::new(trade_rejected_total.clone()))
            .ok();
        registry
            .register(Box::new(trade_executed_total.clone()))
            .ok();
        registry
            .register(Box::new(circuit_breaker_state.clone()))
            .ok();
        registry.register(Box::new(daily_realized_pnl.clone())).ok();
        registry
            .register(Box::new(open_position_count.clone()))
            .ok();
        registry
            .register(Box::new(paper_simulated_pnl.clone()))
            .ok();
        Arc::new(Self {
            registry,
            trades_total,
            trades_success,
            trades_failed,
            hsm_requests,
            hsm_errors,
            latency_hist,
            hsm_latency_hist,
            kill_switch_active,
            last_trade_ts,
            trade_attempt_total,
            trade_rejected_total,
            trade_executed_total,
            circuit_breaker_state,
            daily_realized_pnl,
            open_position_count,
            paper_simulated_pnl,
        })
    }

    /// Render the Prometheus text exposition.
    pub fn render(&self) -> String {
        let encoder = TextEncoder::new();
        let mut buf = Vec::new();
        if encoder.encode(&self.registry.gather(), &mut buf).is_ok() {
            String::from_utf8_lossy(&buf).into_owned()
        } else {
            String::new()
        }
    }
}

/// Spawn the metrics/health HTTP server on `addr`. Returns the listener task.
pub async fn spawn_metrics_server(addr: &str, metrics: Arc<Metrics>) -> Result<(), String> {
    let listener = TcpListener::bind(addr)
        .await
        .map_err(|e| format!("metrics server bind failed on {addr}: {e}"))?;
    tracing::info!(target: "metrics", addr = %addr, "metrics/health server listening");

    loop {
        let (mut socket, _peer) = match listener.accept().await {
            Ok(s) => s,
            Err(e) => {
                tracing::warn!(target: "metrics", err = %e, "accept failed");
                continue;
            }
        };
        let metrics = metrics.clone();
        tokio::spawn(async move {
            let mut buf = [0u8; 2048];
            let _ = socket.read(&mut buf).await;
            let req = String::from_utf8_lossy(&buf);
            let path = req.split_whitespace().nth(1).unwrap_or("/").to_string();

            let (status, body) = match path.as_str() {
                "/health" => ("200 OK", "ok".to_string()),
                "/metrics" => ("200 OK", metrics.render()),
                _ => ("404 Not Found", "not found".to_string()),
            };

            let resp = format!(
                "HTTP/1.1 {status}\r\nContent-Type: text/plain\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
                body.len()
            );
            let _ = socket.write_all(resp.as_bytes()).await;
            let _ = socket.shutdown().await;
        });
    }
}

/// Convenience: record a trade outcome and latency.
pub fn record_trade(metrics: &Metrics, success: bool, latency_ms: f64) {
    metrics.trades_total.inc();
    metrics.latency_hist.observe(latency_ms);
    if success {
        metrics.trades_success.inc();
    } else {
        metrics.trades_failed.inc();
    }
    metrics.last_trade_ts.set(
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as f64,
    );
}

/// Convenience: record an HSM sign request and its latency.
pub fn record_hsm(metrics: &Metrics, ok: bool, latency_ms: f64) {
    metrics.hsm_requests.inc();
    metrics.hsm_latency_hist.observe(latency_ms);
    if !ok {
        metrics.hsm_errors.inc();
    }
}

/// Convenience: set the kill-switch gauge from the risk manager state.
pub fn set_kill_switch(metrics: &Metrics, active: bool) {
    metrics
        .kill_switch_active
        .set(if active { 1.0 } else { 0.0 });
}

/// Convenience: record a risk-gate evaluation attempt for an operating
/// mode (`mode`: "paper" | "dry_run" | "live" | "simulation").
pub fn record_trade_attempt(metrics: &Metrics, mode: &str) {
    metrics.trade_attempt_total.with_label_values(&[mode]).inc();
}

/// Convenience: record a rejection with its operating mode and
/// machine-readable reason code (e.g. `RejectReason::code()` from `risk.rs`).
pub fn record_trade_rejected(metrics: &Metrics, mode: &str, reason_code: &str) {
    metrics
        .trade_rejected_total
        .with_label_values(&[mode, reason_code])
        .inc();
}

/// Convenience: record an executed trade for an operating mode. In live mode
/// this means submitted+confirmed on-chain; in paper mode it means a
/// simulated "would-execute" entry that passed every real gate.
pub fn record_trade_executed(metrics: &Metrics, mode: &str) {
    metrics
        .trade_executed_total
        .with_label_values(&[mode])
        .inc();
}

/// Convenience: refresh the circuit-breaker/open-position/PNL gauges from
/// the current risk manager state.
pub fn set_risk_gauges(
    metrics: &Metrics,
    circuit_breaker_active: bool,
    daily_realized_pnl_lamports: i64,
    open_position_count: u64,
) {
    metrics
        .circuit_breaker_state
        .set(if circuit_breaker_active { 1.0 } else { 0.0 });
    metrics
        .daily_realized_pnl
        .set(daily_realized_pnl_lamports as f64);
    metrics.open_position_count.set(open_position_count as f64);
}

/// Convenience: publish the cumulative simulated P&L of closed paper
/// positions (AŞAMA 4). Always labeled simulated — never mixed with real
/// on-chain realized P&L.
pub fn set_paper_simulated_pnl(metrics: &Metrics, pnl_lamports: i64) {
    metrics.paper_simulated_pnl.set(pnl_lamports as f64);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn metrics_render_contains_counters() {
        let m = Metrics::new();
        record_trade(&m, true, 12.5);
        record_trade(&m, false, 30.0);
        record_hsm(&m, true, 5.0);
        let out = m.render();
        assert!(out.contains("hft_trades_total 2"));
        assert!(out.contains("hft_trades_success 1"));
        assert!(out.contains("hft_trades_failed 1"));
        assert!(out.contains("hft_hsm_requests 1"));
    }

    #[test]
    fn kill_switch_gauge_reflects_state() {
        let m = Metrics::new();
        set_kill_switch(&m, true);
        assert!(m.render().contains("hft_kill_switch_active 1"));
        set_kill_switch(&m, false);
        assert!(m.render().contains("hft_kill_switch_active 0"));
    }

    #[test]
    fn risk_metrics_render_with_reason_label() {
        let m = Metrics::new();
        record_trade_attempt(&m, "paper");
        record_trade_attempt(&m, "live");
        record_trade_rejected(&m, "paper", "stale_price");
        record_trade_rejected(&m, "paper", "stale_price");
        record_trade_rejected(&m, "live", "daily_loss_limit");
        record_trade_executed(&m, "paper");
        set_risk_gauges(&m, true, -150_000_000, 1);
        let out = m.render();
        // Mode-labeled counters: paper and live attempts are separated.
        assert!(out.contains("trade_attempt_total{mode=\"paper\"} 1"));
        assert!(out.contains("trade_attempt_total{mode=\"live\"} 1"));
        assert!(out.contains("trade_rejected_total{mode=\"paper\",reason=\"stale_price\"} 2"));
        assert!(out.contains("trade_rejected_total{mode=\"live\",reason=\"daily_loss_limit\"} 1"));
        assert!(out.contains("trade_executed_total{mode=\"paper\"} 1"));
        assert!(out.contains("circuit_breaker_state 1"));
        assert!(out.contains("daily_realized_pnl -150000000"));
        assert!(out.contains("open_position_count 1"));
    }

    #[tokio::test]
    async fn health_endpoint_returns_ok() {
        let m = Metrics::new();
        let addr = "127.0.0.1:0";
        // Bind to an ephemeral port to avoid conflicts.
        let listener = TcpListener::bind(addr).await.unwrap();
        let bound = listener.local_addr().unwrap();
        drop(listener);

        let server_addr = format!("127.0.0.1:{}", bound.port());
        let m2 = m.clone();
        let server_addr_for_task = server_addr.clone();
        let handle = tokio::spawn(async move {
            let _ = spawn_metrics_server(&server_addr_for_task, m2).await;
        });

        // Give the server a moment to bind.
        tokio::time::sleep(std::time::Duration::from_millis(200)).await;

        let resp = reqwest::get(&format!("http://{server_addr}/health"))
            .await
            .unwrap();
        assert_eq!(resp.status(), 200);
        let body = resp.text().await.unwrap();
        assert_eq!(body, "ok");

        handle.abort();
    }
}
